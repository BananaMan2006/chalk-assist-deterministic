#import <AppKit/AppKit.h>
#import "MatchGate.h"
#include <math.h>

// Read the override for this process only; otherwise use the current user's home.
static NSString *workspaceFile(NSString *name) {
    NSString *override = NSProcessInfo.processInfo.environment[@"CHALK_EXECUTOR_WORKSPACE"];
    NSString *root = override.length ? [override stringByExpandingTildeInPath] :
        [NSHomeDirectory() stringByAppendingPathComponent:@"Opiumware/workspace"];
    return [root stringByAppendingPathComponent:name];
}
static NSString *const GatePreference = @"ChalkMatchGateStateV1";
static NSString *const EnabledPreference = @"ChalkMatchAlertsEnabledV1";

static BOOL booleanValue(id value) {
    return [value isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID();
}

@interface MatchPanel : NSPanel @end
@implementation MatchPanel
- (BOOL)canBecomeMainWindow { return NO; }
- (BOOL)canBecomeKeyWindow { return NO; }
@end
@interface MatchButton : NSButton @end
@implementation MatchButton
- (BOOL)acceptsFirstMouse:(NSEvent *)event { return YES; }
@end

static NSWindowCollectionBehavior windowBehavior(void) {
    NSWindowCollectionBehavior flags = NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorFullScreenAuxiliary | NSWindowCollectionBehaviorIgnoresCycle;
    if (@available(macOS 13.0, *)) flags |= NSWindowCollectionBehaviorCanJoinAllApplications;
    return flags;
}
static NSTextField *label(NSString *text, NSFont *font, NSRect frame) {
    NSTextField *field = [NSTextField wrappingLabelWithString:text];
    field.font = font;
    field.frame = frame;
    field.selectable = NO;
    return field;
}

@interface MatchAlerts : NSObject <NSApplicationDelegate>
@property (strong) NSStatusItem *statusItem;
@property (strong) NSMutableArray<MatchPanel *> *panels;
@property (strong) NSSound *chime;
@property (strong) NSTimer *timer;
@property (strong) ChalkMatchGate *gate;
@property (copy) NSDictionary *lastSavedGate;
@property (copy) NSString *shownTitle;
@property (copy) NSString *shownBody;
@property BOOL testOnly;
@property BOOL quitRequested;
@property BOOL alertsEnabled;
@property NSTimeInterval lastFresh;
@property NSTimeInterval nextStatusAt;
@property NSTimeInterval nextHeartbeatAt;
@end

@implementation MatchAlerts
- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    self.panels = [NSMutableArray array];
    self.gate = [[ChalkMatchGate alloc] initWithSavedState:
        [NSUserDefaults.standardUserDefaults dictionaryForKey:GatePreference]];
    self.lastSavedGate = self.gate.savedState;
    id savedEnabled = [NSUserDefaults.standardUserDefaults objectForKey:EnabledPreference];
    self.alertsEnabled = booleanValue(savedEnabled) ? [savedEnabled boolValue] : YES;
    self.lastFresh = NSDate.date.timeIntervalSince1970;
    self.testOnly = [NSProcessInfo.processInfo.arguments containsObject:@"--test"];
    self.statusItem = [NSStatusBar.systemStatusBar statusItemWithLength:NSVariableStatusItemLength];
    self.statusItem.button.title = @"Match alerts";
    self.statusItem.button.toolTip = @"Chalk It Up match alerts";
    NSMenu *menu = [[NSMenu alloc] initWithTitle:@"Match alerts"];
    NSMenuItem *test = [[NSMenuItem alloc] initWithTitle:@"Show test alert" action:@selector(showTest:) keyEquivalent:@""];
    test.target = self;
    [menu addItem:test];
    [menu addItem:NSMenuItem.separatorItem];
    NSMenuItem *quit = [[NSMenuItem alloc] initWithTitle:@"Quit Match alerts" action:@selector(quit:) keyEquivalent:@""];
    quit.target = self;
    [menu addItem:quit];
    self.statusItem.menu = menu;
    [self updateAlertPreference];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(screensChanged:)
        name:NSApplicationDidChangeScreenParametersNotification object:nil];
    self.timer = [NSTimer timerWithTimeInterval:0.5 target:self selector:@selector(tick:)
        userInfo:nil repeats:YES];
    [NSRunLoop.mainRunLoop addTimer:self.timer forMode:NSRunLoopCommonModes];
    [self audit:@"started" source:@"helper" payload:nil];
    if (self.testOnly) [self showTest:nil];
    [self tick:nil];
}
- (void)dismiss:(id)sender {
    for (MatchPanel *panel in self.panels) [panel orderOut:nil];
    [self.panels removeAllObjects];
    self.shownTitle = nil;
    self.shownBody = nil;
}
- (void)quit:(id)sender { self.quitRequested=YES; [NSApp terminate:nil]; }
- (void)showTest:(id)sender {
    [self updateAlertPreference];
    if (!self.alertsEnabled) {
        [self audit:@"muted" source:@"manual_test" payload:nil];
        return;
    }
    [self showTitle:@"TEST — Match alert"
        body:@"This is a test, not a new match. This panel should stay above your other apps until you dismiss it."
        sound:YES];
    [self audit:@"panel_requested" source:@"manual_test" payload:nil];
}
- (void)screensChanged:(NSNotification *)notification {
    if (self.shownTitle) [self showTitle:self.shownTitle body:self.shownBody sound:NO];
}
- (void)showTitle:(NSString *)title body:(NSString *)body sound:(BOOL)sound {
    // Copy before clearing, because a display change can pass the stored strings.
    NSString *savedTitle = [title copy], *savedBody = [body copy];
    [self dismiss:nil];
    self.shownTitle = savedTitle;
    self.shownBody = savedBody;
    for (NSScreen *screen in NSScreen.screens) {
        NSRect visible = screen.visibleFrame;
        CGFloat width = MIN(390, MAX(250, visible.size.width - 36));
        CGFloat height = 151;
        MatchPanel *panel = [[MatchPanel alloc] initWithContentRect:NSMakeRect(0, 0, width, height)
            styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskNonactivatingPanel
            backing:NSBackingStoreBuffered defer:NO];
        panel.title = @"Chalk Match Alerts";
        panel.accessibilityLabel = savedTitle;
        panel.floatingPanel = YES;
        panel.becomesKeyOnlyIfNeeded = YES;
        panel.hidesOnDeactivate = NO;
        panel.level = NSStatusWindowLevel;
        panel.collectionBehavior = windowBehavior();
        panel.sharingType = NSWindowSharingReadOnly;
        panel.releasedWhenClosed = NO;
        panel.movableByWindowBackground = YES;
        NSView *content = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, height)];
        panel.contentView = content;
        [content addSubview:label(savedTitle, [NSFont boldSystemFontOfSize:19], NSMakeRect(18, 109, width - 36, 28))];
        NSTextField *detail = label(savedBody, [NSFont systemFontOfSize:13], NSMakeRect(18, 49, width - 36, 55));
        detail.textColor = NSColor.secondaryLabelColor;
        [content addSubview:detail];
        MatchButton *dismiss = [MatchButton buttonWithTitle:@"Dismiss" target:self action:@selector(dismiss:)];
        dismiss.bezelStyle = NSBezelStyleRounded;
        dismiss.frame = NSMakeRect(width - 111, 12, 94, 29);
        [content addSubview:dismiss];
        [panel setFrameOrigin:NSMakePoint(NSMaxX(visible) - panel.frame.size.width - 18,
            NSMaxY(visible) - panel.frame.size.height - 18)];
        [self.panels addObject:panel];
        [panel orderFrontRegardless]; // Does not activate the helper or take typing focus.
    }
    if (sound) {
        self.chime = [NSSound soundNamed:@"Glass"];
        [self.chime play];
    }
}
- (id)readJSON:(NSString *)path modified:(NSTimeInterval *)modified {
    NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:path error:nil];
    NSDate *date = attributes[NSFileModificationDate];
    *modified = date ? date.timeIntervalSince1970 : -INFINITY;
    if ([attributes[NSFileSize] unsignedLongLongValue] > 1024 * 1024) return nil;
    NSData *data = [NSData dataWithContentsOfFile:path];
    return data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
}
- (void)updateAlertPreference {
    NSTimeInterval modified;
    id settings = [self readJSON:workspaceFile(@"ciu_match_alert_settings.json") modified:&modified];
    id enabled = [settings isKindOfClass:NSDictionary.class] ? settings[@"enabled"] : nil;
    // Settings persist across joins; unlike game events they do not expire.
    // A partial write or missing file retains the last valid choice.
    if (booleanValue(enabled) && self.alertsEnabled != [enabled boolValue]) {
        self.alertsEnabled = [enabled boolValue];
        [NSUserDefaults.standardUserDefaults setBool:self.alertsEnabled forKey:EnabledPreference];
        [self audit:self.alertsEnabled ? @"alerts_enabled" : @"alerts_disabled" source:@"settings" payload:nil];
        self.nextHeartbeatAt = 0;
    }
    self.statusItem.button.title = self.alertsEnabled ? @"Match alerts" : @"Match alerts: off";
    self.statusItem.button.toolTip = self.alertsEnabled ? @"Chalk It Up match alerts are on" :
        @"Chalk It Up match alerts are off. Change Match Alerts in the game panel.";
    if (!self.alertsEnabled) {
        [self.chime stop];
        if (self.panels.count) [self dismiss:nil];
    }
}
- (void)saveGate {
    NSDictionary *state = self.gate.savedState;
    if (![state isEqual:self.lastSavedGate]) {
        [NSUserDefaults.standardUserDefaults setObject:state forKey:GatePreference];
        self.lastSavedGate = state;
    }
}
- (void)audit:(NSString *)action source:(NSString *)source payload:(NSDictionary *)payload {
    // Bounded local record of attempted presentation, not proof the user saw it.
    NSURL *url = [NSBundle.mainBundle.bundleURL.URLByDeletingLastPathComponent
        URLByAppendingPathComponent:@"alert-audit.json"];
    NSData *oldData = [NSData dataWithContentsOfURL:url];
    id old = oldData && oldData.length < 1024 * 1024 ?
        [NSJSONSerialization JSONObjectWithData:oldData options:0 error:nil] : nil;
    NSMutableArray *entries = [old isKindOfClass:NSArray.class] ? [old mutableCopy] : [NSMutableArray array];
    NSMutableDictionary *entry = [@{@"at":@(NSDate.date.timeIntervalSince1970),@"action":action,@"source":source,
        @"version":@"1.4"} mutableCopy];
    for (NSString *key in @[@"id",@"time",@"jobId",@"mode"]) {
        if ([payload[key] isKindOfClass:NSString.class] || [payload[key] isKindOfClass:NSNumber.class]) entry[key] = payload[key];
    }
    [entries addObject:entry];
    while (entries.count > 80) [entries removeObjectAtIndex:0];
    NSData *data = [NSJSONSerialization dataWithJSONObject:entries options:NSJSONWritingPrettyPrinted error:nil];
    [data writeToURL:url options:NSDataWritingAtomic error:nil];
}
- (void)announce:(NSDictionary *)payload source:(NSString *)source {
    // The gate has already consumed this match. Muting presentation here avoids
    // replaying a match that was found while alerts were turned off.
    if (!self.alertsEnabled) {
        [self audit:@"muted" source:source payload:payload];
        return;
    }
    NSString *mode = [payload[@"mode"] isKindOfClass:NSString.class] ? payload[@"mode"] : nil;
    if ([mode isEqual:@"Ranked1v1"]) mode = @"Ranked 1v1";
    if ([mode isEqual:@"Ranked2v2"]) mode = @"Ranked 2v2";
    NSString *body = mode ? [NSString stringWithFormat:@"Your %@ match is ready.",mode] : @"Your match is ready.";
    // No frontmost-app filter and no skip when another alert is already showing.
    [self showTitle:@"Game found — Chalk It Up" body:body sound:YES];
    [self audit:@"panel_requested" source:source payload:payload];
}
- (void)writeHeartbeat:(BOOL)running {
    NSURL *url = [NSBundle.mainBundle.bundleURL.URLByDeletingLastPathComponent
        URLByAppendingPathComponent:@"helper-status.json"];
    NSDictionary *status = @{@"time":@(NSDate.date.timeIntervalSince1970),@"version":@"1.4",
        @"running":@(running),@"pid":@(NSProcessInfo.processInfo.processIdentifier),
        @"lastFreshGameData":@(self.lastFresh),@"panels":@(self.panels.count),
        @"alertsEnabled":@(self.alertsEnabled)};
    NSData *data = [NSJSONSerialization dataWithJSONObject:status options:0 error:nil];
    [data writeToURL:url options:NSDataWritingAtomic error:nil];
}
- (void)tick:(NSTimer *)timer {
    NSTimeInterval now = NSDate.date.timeIntervalSince1970, modified;
    [self updateAlertPreference];
    id event = [self readJSON:workspaceFile(@"ciu_match_alert.json") modified:&modified];
    if (ChalkValidEvent(event, modified, now)) {
        self.lastFresh = now;
        if (!self.testOnly) {
            NSString *decision = [self.gate found:event now:now];
            if ([decision isEqual:@"alert"]) [self announce:event source:@"queue_found"];
            else if ([decision isEqual:@"phase_already_alerted"]) [self audit:decision source:@"queue_found" payload:event];
            [self saveGate];
        }
    }
    if (now >= self.nextStatusAt) {
        self.nextStatusAt = now + 2;
        id root = [self readJSON:workspaceFile(@"ciu_live_status.json") modified:&modified];
        if (ChalkValidStatus(root, modified, now)) {
            self.lastFresh = now;
            if (!self.testOnly) {
                NSString *decision = [self.gate status:root now:now];
                if ([decision isEqual:@"alert"]) [self announce:root source:@"phase_fallback"];
                else if ([decision isEqual:@"found_already_alerted"]) [self audit:decision source:@"phase_fallback" payload:root];
                [self saveGate];
            }
        }
    }
    // Keep watching through long breaks and Roblox restarts. Only an explicit
    // Quit or normal application termination stops this helper.
    if (now >= self.nextHeartbeatAt) {
        self.nextHeartbeatAt = now + 15;
        [self writeHeartbeat:YES];
    }
}
- (void)applicationWillTerminate:(NSNotification *)notification {
    [self audit:self.quitRequested ? @"quit_by_user" : @"terminated" source:@"helper" payload:nil];
    [self.timer invalidate];
    [NSNotificationCenter.defaultCenter removeObserver:self];
    [self dismiss:nil];
    [self writeHeartbeat:NO];
    [NSUserDefaults.standardUserDefaults synchronize];
    // launchd restarts unexpected exits. The explicit menu Quit remains off
    // for this login session. NSApplication terminate: does not return to main.
    exit(self.quitRequested ? EXIT_SUCCESS : EXIT_FAILURE);
}
@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc == 2 && strcmp(argv[1], "--self-test") == 0) return ChalkGateSelfTest();
        NSApplication *app = NSApplication.sharedApplication;
        [app setActivationPolicy:NSApplicationActivationPolicyAccessory];
        __attribute__((objc_precise_lifetime)) MatchAlerts *delegate = [[MatchAlerts alloc] init];
        app.delegate = delegate;
        [app run];
        (void)delegate;
    }
    return 0;
}
