#import <Foundation/Foundation.h>

BOOL ChalkValidEvent(id value, NSTimeInterval modified, NSTimeInterval now);
BOOL ChalkValidStatus(id value, NSTimeInterval modified, NSTimeInterval now);
int ChalkGateSelfTest(void);

// Pure event/phase deduplication. No file, UI, preference, or notification APIs.
@interface ChalkMatchGate : NSObject
@property (copy) NSString *lastEventID;
@property NSTimeInterval lastEventAt;
@property (copy) NSString *lastJob;
@property BOOL armed;
@property NSTimeInterval pendingArrivalUntil;
@property NSTimeInterval lastFallbackAt;
- (instancetype)initWithSavedState:(NSDictionary *)saved;
- (NSDictionary *)savedState;
- (NSString *)found:(NSDictionary *)event now:(NSTimeInterval)now;
- (NSString *)status:(NSDictionary *)root now:(NSTimeInterval)now;
@end
