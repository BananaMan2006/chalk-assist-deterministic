#!/bin/bash
set -eu
base="$(cd -P "$(dirname "$0")" && pwd)"
bundle="${CHALK_ALERTS_OUTPUT_BUNDLE:-$base/Chalk Match Alerts.app}"
/bin/mkdir -p "$bundle/Contents/MacOS"
/usr/bin/xcrun clang -fobjc-arc -O2 -Wall -Wextra -Wno-unused-parameter \
    -framework AppKit -framework Foundation "$base/MatchAlerts.m" "$base/MatchGate.m" \
    -o "$bundle/Contents/MacOS/ChalkMatchAlerts"
/bin/cp "$base/Info.plist" "$bundle/Contents/Info.plist"
/usr/bin/codesign --force --sign - "$bundle"
/usr/bin/codesign --verify --strict "$bundle"
/usr/bin/plutil -lint "$bundle/Contents/Info.plist"
printf '%s\n' "$bundle"
