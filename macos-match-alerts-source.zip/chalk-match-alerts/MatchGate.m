#import "MatchGate.h"
#include <math.h>

static BOOL text(id value) { return [value isKindOfClass:NSString.class] && [value length] > 0; }
static BOOL number(id value) { return [value isKindOfClass:NSNumber.class] && isfinite([value doubleValue]); }
static BOOL fresh(NSTimeInterval stamp, NSTimeInterval now, NSTimeInterval limit) {
    NSTimeInterval age = now - stamp;
    return isfinite(stamp) && isfinite(now) && age >= -5 && age <= limit;
}
static BOOL identity(id value) {
    if (![value isKindOfClass:NSDictionary.class]) return NO;
    return number(value[@"gameId"]) && [value[@"gameId"] doubleValue] == 10770281752.0 &&
        number(value[@"placeId"]) && [value[@"placeId"] doubleValue] == 116097127629859.0 &&
        text(value[@"jobId"]);
}
BOOL ChalkValidEvent(id value, NSTimeInterval modified, NSTimeInterval now) {
    if (!identity(value) || !fresh(modified, now, 120) || !text(value[@"id"]) ||
        !number(value[@"time"]) || !fresh([value[@"time"] doubleValue], now, 120) ||
        !text(value[@"mode"])) return NO;
    return [@[@"1v1", @"2v2", @"3v3", @"Ranked1v1", @"Ranked2v2"] containsObject:value[@"mode"]];
}
BOOL ChalkValidStatus(id value, NSTimeInterval modified, NSTimeInterval now) {
    return identity(value) && fresh(modified, now, 5) && number(value[@"time"]) &&
        fresh([value[@"time"] doubleValue], now, 5) &&
        [value[@"status"] isKindOfClass:NSDictionary.class];
}

@implementation ChalkMatchGate
- (instancetype)initWithSavedState:(NSDictionary *)saved {
    self = [super init];
    if (self) {
        self.armed = YES;
        if ([saved isKindOfClass:NSDictionary.class] && [saved[@"version"] isEqual:@1]) {
            self.lastEventID = text(saved[@"lastEventID"]) ? saved[@"lastEventID"] : nil;
            self.lastEventAt = number(saved[@"lastEventAt"]) ? [saved[@"lastEventAt"] doubleValue] : 0;
            self.lastJob = text(saved[@"lastJob"]) ? saved[@"lastJob"] : nil;
            if ([saved[@"armed"] isKindOfClass:NSNumber.class]) self.armed = [saved[@"armed"] boolValue];
            self.pendingArrivalUntil = number(saved[@"pendingArrivalUntil"]) ? [saved[@"pendingArrivalUntil"] doubleValue] : 0;
            self.lastFallbackAt = number(saved[@"lastFallbackAt"]) ? [saved[@"lastFallbackAt"] doubleValue] : 0;
        }
    }
    return self;
}
- (NSDictionary *)savedState {
    return @{@"version":@1, @"lastEventID":self.lastEventID ?: @"", @"lastEventAt":@(self.lastEventAt),
        @"lastJob":self.lastJob ?: @"", @"armed":@(self.armed),
        @"pendingArrivalUntil":@(self.pendingArrivalUntil), @"lastFallbackAt":@(self.lastFallbackAt)};
}
- (NSString *)found:(NSDictionary *)event now:(NSTimeInterval)now {
    NSString *identifier = event[@"id"];
    NSTimeInterval eventAt = [event[@"time"] doubleValue];
    if ([identifier isEqualToString:self.lastEventID]) return @"duplicate";
    if (eventAt < self.lastEventAt - 0.001) return @"older_event";
    self.lastEventID = identifier;
    self.lastEventAt = eventAt;
    // A durable Found written before a phase we already announced is the same
    // arrival. A later Found with a new ID is a new match, even within 120 sec.
    if (self.lastFallbackAt > 0 && eventAt <= self.lastFallbackAt + 0.1 &&
        self.lastFallbackAt - eventAt <= 120) {
        self.pendingArrivalUntil = 0;
        return @"phase_already_alerted";
    }
    self.pendingArrivalUntil = now + 120;
    return @"alert";
}
- (NSString *)status:(NSDictionary *)root now:(NSTimeInterval)now {
    NSString *job = root[@"jobId"];
    NSDictionary *status = root[@"status"];
    if (![self.lastJob isEqualToString:job]) { self.lastJob = job; self.armed = YES; }
    id phase = status[@"phase"], role = status[@"role"];
    if ([phase isEqual:@"Lobby"]) { self.armed = YES; return @"lobby"; }
    if (![phase isKindOfClass:NSString.class]) return @"unsupported_phase";
    BOOL pick = [phase isEqual:@"Pick"];
    BOOL knownRole = [role isKindOfClass:NSString.class] &&
        [@[@"WR", @"DB", @"QB", @"TWR", @"TDB", @"TQB"] containsObject:role];
    BOOL match = [@[@"Pick", @"PreSnap", @"Hike", @"Live", @"RAC", @"Result"] containsObject:phase];
    if (!match || (!pick && !knownRole) || !self.armed) return @"no_transition";
    self.armed = NO;
    if (self.pendingArrivalUntil > 0 && now <= self.pendingArrivalUntil) {
        self.pendingArrivalUntil = 0;
        return @"found_already_alerted";
    }
    self.pendingArrivalUntil = 0;
    self.lastFallbackAt = now;
    return @"alert";
}
@end

int ChalkGateSelfTest(void) {
    NSMutableArray *results = [NSMutableArray array];
    void (^check)(NSString *, BOOL) = ^(NSString *name, BOOL passed) {
        [results addObject:@{@"name":name, @"passed":@(passed)}];
    };
    NSDictionary *(^event)(NSString *, double) = ^NSDictionary *(NSString *identifier, double at) {
        return @{@"id":identifier,@"time":@(at),@"gameId":@10770281752LL,@"placeId":@116097127629859LL,
            @"jobId":@"queue-server",@"mode":@"Ranked2v2"};
    };
    NSDictionary *(^status)(NSString *, NSString *, id, double) = ^NSDictionary *(NSString *job, NSString *phase, id role, double at) {
        return @{@"time":@(at),@"gameId":@10770281752LL,@"placeId":@116097127629859LL,
            @"jobId":job,@"status":@{@"phase":phase,@"role":role ?: NSNull.null}};
    };
    check(@"fresh durable Found accepted", ChalkValidEvent(event(@"a",1000),1000,1001));
    check(@"stale event rejected despite fresh file", !ChalkValidEvent(event(@"a",800),1000,1001));
    check(@"stale file rejected despite fresh payload", !ChalkValidEvent(event(@"a",1000),800,1001));
    check(@"far future event rejected", !ChalkValidEvent(event(@"a",1010),1000,1001));
    check(@"small server clock lead accepted", ChalkValidEvent(event(@"a",1003),1000,1001));
    NSMutableDictionary *bad = [event(@"a",1000) mutableCopy]; bad[@"gameId"]=@1;
    check(@"wrong game rejected", !ChalkValidEvent(bad,1000,1001));
    bad = [event(@"a",1000) mutableCopy]; bad[@"mode"]=@"unsupported";
    check(@"unknown mode rejected", !ChalkValidEvent(bad,1000,1001));
    check(@"status requires fresh time and file", ChalkValidStatus(status(@"j",@"Live",@"DB",1000),1000,1001) &&
        !ChalkValidStatus(status(@"j",@"Live",@"DB",990),1000,1001));
    ChalkMatchGate *g = [[ChalkMatchGate alloc] initWithSavedState:nil];
    check(@"first Found alerts", [[g found:event(@"a",1000) now:1001] isEqual:@"alert"]);
    check(@"same Found never repeats", [[g found:event(@"a",1000) now:1002] isEqual:@"duplicate"]);
    [g status:status(@"queue-server",@"Lobby",nil,1002) now:1002];
    check(@"cross-server Pick is deduplicated", [[g status:status(@"match-server",@"Pick",nil,1003) now:1003] isEqual:@"found_already_alerted"]);
    check(@"following downs stay quiet", [[g status:status(@"match-server",@"PreSnap",@"DB",1010) now:1010] isEqual:@"no_transition"]);
    check(@"new Found alerts inside prior 120 second window", [[g found:event(@"b",1011) now:1011] isEqual:@"alert"]);
    ChalkMatchGate *restored = [[ChalkMatchGate alloc] initWithSavedState:g.savedState];
    check(@"restart remembers consumed event", [[restored found:event(@"b",1011) now:1012] isEqual:@"duplicate"]);
    check(@"restart remembers pending arrival", [[restored status:status(@"next-server",@"Live",@"TWR",1013) now:1013] isEqual:@"found_already_alerted"]);
    [restored status:status(@"next-server",@"Lobby",nil,1030) now:1030];
    check(@"phase-only next match still alerts", [[restored status:status(@"next-server",@"Pick",nil,1031) now:1031] isEqual:@"alert"]);
    check(@"late-written preceding Found deduplicates fallback", [[restored found:event(@"c",1030) now:1032] isEqual:@"phase_already_alerted"]);
    check(@"new later Found after fallback alerts", [[restored found:event(@"d",1033) now:1033] isEqual:@"alert"]);
    check(@"out-of-order old ID does not alert", [[restored found:event(@"old",1020) now:1034] isEqual:@"older_event"]);
    ChalkMatchGate *malformed = [[ChalkMatchGate alloc] initWithSavedState:@{@"version":@1,@"armed":NSNull.null}];
    check(@"malformed or missing role is safe", ![[malformed status:status(@"x",@"Live",NSNull.null,1000) now:1000] isEqual:@"alert"]);
    check(@"Pick can start before roles are assigned", [[malformed status:status(@"x",@"Pick",nil,1001) now:1001] isEqual:@"alert"]);
    NSUInteger failed=0; for (NSDictionary *r in results) if (![r[@"passed"] boolValue]) failed++;
    NSData *json = [NSJSONSerialization dataWithJSONObject:@{@"total":@(results.count),@"failed":@(failed),
        @"passed":@(results.count-failed),@"results":results} options:NSJSONWritingPrettyPrinted error:nil];
    fwrite(json.bytes,1,json.length,stdout); fputc('\n',stdout);
    return failed ? 1 : 0;
}
